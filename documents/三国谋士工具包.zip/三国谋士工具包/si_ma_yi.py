#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
si_ma_yi.py — 独立可执行的谋士咨询工具
====================================
此文件可独立运行，无需其他谋士工具。

用法:
    python si_ma_yi.py "你的问题"
    echo "你的问题" | python si_ma_yi.py
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from strategist import consult, show_list
from personas import ALL_STRATEGISTS

if __name__ == "__main__":
    args = sys.argv[1:]
    if not args:
        # 从 stdin 读取
        question = sys.stdin.read().strip()
        if not question:
            print("用法: python si_ma_yi.py \"你的问题\"")
            sys.exit(1)
        consult("si_ma_yi", question)
    elif args[0] in ("--list","-l"):
        show_list()
    else:
        consult("si_ma_yi", " ".join(args))
