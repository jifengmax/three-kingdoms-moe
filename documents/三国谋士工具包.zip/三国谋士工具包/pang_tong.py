#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pang_tong.py — 独立可执行的谋士咨询工具
====================================
此文件可独立运行，无需其他谋士工具。

用法:
    python pang_tong.py "你的问题"
    echo "你的问题" | python pang_tong.py
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from strategist import consult, show_list
from personas import ALL_STRATEGISTS

if __name__ == "__main__":
    args = sys.argv[1:]
    if not args:
        # 从 stdin 读取
        question = sys.stdin.read().strip()
        if not question:
            print("用法: python pang_tong.py \"你的问题\"")
            sys.exit(1)
        consult("pang_tong", question)
    elif args[0] in ("--list","-l"):
        show_list()
    else:
        consult("pang_tong", " ".join(args))
